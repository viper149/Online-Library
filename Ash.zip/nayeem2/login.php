<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">



    
   
    <title>Online Book reading</title>
<link rel="stylesheet" type="text/css" href="header.css">
 <link href='https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300,300italic,700' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Cookie' rel='stylesheet' type='text/css'>

<?php

if(isset($_POST["submit"])){

    if(!empty($_POST['name']) && !empty($_POST['pass'])) {
        $user=$_POST['name'];
        $pass=$_POST['pass'];
    
        $con=mysql_connect('localhost','root','') or die(mysql_error());
        mysql_select_db('nayeem1') or die("cannot select DB");
    
        $query=mysql_query("SELECT * FROM login WHERE name='".$name."' AND password='".$pass."'");
        $numrows=mysql_num_rows($query);
        if($numrows!=0)
        {
        while($row=mysql_fetch_assoc($query))
        {
        $dbname=$row['name'];
        $dbpassword=$row['password'];
        }
    
        if($user == $dbname && $pass == $dbpassword)
        {
        session_start();
        $_SESSION['sess_user']=$user;
    
        
        header("Location: index.php");
        }
        } else {
        echo "Invalid username or password!";
        }
    
    } else {
        echo "All fields are required!";
    }
    }

?>
</head>

<body>
<header>
<h1> Online<img src ="bok.jpg" height ='100'>reading</h1>
</header> 


<div class='diva'></div>
<ul>

<li><a  href='index.php'>Forums</a></li>
<li><a href='member'>Membership</a></li>
<li><a href='help'>Help</a></li>
<li><a href='login.php'>Login</a></li>
<li><a href='reg.php'>SignUp</a></li>
<li><a href='about'>AboutUs</a></li>
</ul>
<div class='divs'></div><br>

<div class="ai">
<form action="" method="post">
<table width ="450px">
</tr>

<tr>
<td>
<label for ="first_name">User Name:</label>
</td>
</tr>
<td>
<input type ="text" name="name" placeholder="user_name" required maxlength ="50" size="40"  >
</td>
</tr>
<tr>
<td>
<label for ="last_name">Password:</label>
</td>
</tr>
<td>
<input type ="password" name="password" placeholder="Password" required maxlength ="50" size="40" >
</td>
</tr>
<tr>
<td>
</tr>
<tr>
<td style= "text-algin:center"><br>
<input type ="submit" value="Login">
</table>
</form>  

</div>


</body>
</html>


