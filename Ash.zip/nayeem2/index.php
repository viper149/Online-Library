<!DOCTYPE html>
<html lang="en">
<head>
  
   
    <title>Online Book reading</title>
<link rel="stylesheet" type="text/css" href="header.css">
 <link href='https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300,300italic,700' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Cookie' rel='stylesheet' type='text/css'>



</head>

<body >

<header>
<h1> Online<img src ="bok.jpg" height ='100'>reading</h1>
</header> 


<div class='diva'></div>
<ul>

<li><a  href='index.php'>Forums</a></li>
<li><a href='member'>Membership</a></li>
<li><a href='help'>Help</a></li>
<li><a href='login.php'>Login</a></li>
<li><a href='reg.php'>SignUp</a></li>
<li><a href='about'>AboutUs</a></li>

</ul>


<div class='divs'></div><br><br>

<div class = 'all'>
<div class ='combo'> 
<h2>BooksCategory</h2>
<select>
<option>Since</option>
<option> buisness </option>
<option> nobel </option>
</select>
</div>




<div class='fimage1'>

<a href="pdf/Nil.pdf"><img src = "pdf/image.png" alt="thumbnail" height="150px" width="150px"/></a>	
<a href="pdf/Tin.pdf"><img src = "pdf/logo.png" alt="thumbnail" height="150px"width="150px"/></a>
<a href="pdf/Bodhodoy.pdf"><img src = "pdf/logo1.png" alt="thumbnail" height="150px" width="150px"/><a>
<a href="pdf/tale.pdf"><img src = "pdf/logo2.jpg" alt="thumbnail" height="150px" width="150px"/><a>
<a href="pdf/Alices.pdf"><img src = "pdf/logo3.jpg" alt="thumbnail" height="150px" width="150px"/></a>






<body>

</html>

